/**
 * Class comments go here...
 *
 * @author José Carlos Mazella Junior
 * @version 1.0 $DAY/$MONTH/$YEAR
 */